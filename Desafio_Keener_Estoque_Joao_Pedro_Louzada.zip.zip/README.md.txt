# Desafio Técnico - Controle de Estoque Kenner

## Como rodar o projeto
1. Instale as dependências: `pip install -r requirements.txt`
2. Inicie o servidor: `python manage.py runserver`

## Acesso de Teste (Admin)
- **Usuário:** Admin.Kenner
- **Senha:** 12345678

## Funcionalidades
- Cadastro de Produtos e Movimentações (Entrada/Saída).
- Trava de segurança para estoque negativo.
- Histórico completo e busca integrada.